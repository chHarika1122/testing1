package cucumberOption;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "src/main/java/features/sample.feature",
       glue= {"stepdefinitions"},
       //dryRun=true,
      // monochrome=true
       //strict=true,
        tags= {"@RegressionTest"},
       plugin = {"html:target/Destination"}
       )


public class TestRunner {

}