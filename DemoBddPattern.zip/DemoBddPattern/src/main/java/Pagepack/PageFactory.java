package Pagepack;

public class PageFactory {


	
	
}
