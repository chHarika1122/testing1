package demopattern;

import org.openqa.selenium.By;

public class AssertionsConcept {

	public static By Registerlink=By.linkText("Register");
	public static By LinkText=By.linkText("REGISTER");
	public static By FirstName=By.xpath("//input[@name='firstname']");
	public static By LastName=By.xpath("//input[@name='latsname']");
	public static By hotel=By.xpath("//a[@href='mercuryunderconst.php']");
 }
