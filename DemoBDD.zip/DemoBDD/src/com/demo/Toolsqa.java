package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Toolsqa {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.toolsqa.com/automation-practice-switch-windows/");
		String Parent_Window = driver.getWindowHandle();
		driver.switchTo().window(Parent_Window);
		System.out.println(Parent_Window);
		driver.manage().window().maximize();
		driver.findElement(By.id("cookie_action_close_header")).click();
		WebElement element=driver.findElement(By.xpath("//button[text()='New Message Window']"));
		element.click();
		//System.out.println(element.getText());
		for(String ChildWindow : driver.getWindowHandles()){
			System.out.println(ChildWindow);
				driver.switchTo().window(ChildWindow);
				
				}
		
}
}
