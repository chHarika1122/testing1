package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Practice {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("http://demowebshop.tricentis.com");
		driver.findElement(By.linkText("Register")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("register-button")).click();
		WebElement element=driver.findElement(By.xpath("//span[@data-valmsg-for='FirstName']"));
		System.out.println(element.getText());
		WebElement element1=driver.findElement(By.name("register-button"));
		System.out.println(element1.getAttribute("value"));
		//System.out.println(element1.getCssValue(""));
		
		
		
		driver.findElement(By.id("gender-female")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("FirstName")).sendKeys("Abcd");
		Thread.sleep(2000);
		driver.findElement(By.id("LastName")).sendKeys("Efgh");
		Thread.sleep(2000);
		driver.findElement(By.id("Email")).sendKeys("ababababab@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("Password")).sendKeys("Abcdef");
		Thread.sleep(2000);
		driver.findElement(By.id("ConfirmPassword")).sendKeys("Abcdef");
		Thread.sleep(2000);
		driver.findElement(By.id("register-button")).click();
		Thread.sleep(2000);
		/*driver.findElement(By.linkText("Log in")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("Email")).sendKeys("ababababab@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("Password")).sendKeys("Abcdef");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='Log in']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@href='/computers']")).click();
		Thread.sleep(3000);*/
		//driver.findElement(By.className("//a[@href='/desktops']")).click();
	   /* driver.findElement(By.xpath("//img[@alt='Picture for category Desktops']")).click();*/
	 /*   Select sel=new Select(driver.findElement(By.className("product-sorting")));
	    sel.selectByValue("http://demowebshop.tricentis.com/desktops?orderby=10");*/
	    
	   /* driver.findElement(By.className("product-sorting")).click();
	    Select sel=new Select(driver.findElement(By.id("products-orderby")));
	    sel.selectByValue("http://demowebshop.tricentis.com/desktops?orderby=10");*/
	    
		//Select sel=new Select(driver.findElement(By.id("")));
	   /* <option selected="selected" value="http://demowebshop.tricentis.com/desktops?orderby=10">Price: Low to High</option>*/		
		/*driver.findElement(By.id("RememberMe")).click();
		Thread.sleep(2000);*/
		
		
		/*
		driver.findElement(By.linkText("Log out")).click();*/
		
		
		//driver.manage().window().maximize();
	    //tag[@attribute='']
	}
}
