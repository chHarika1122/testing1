package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DemoBDD {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.get("https://www.capgemini.com");
	    driver.navigate().to("https://www.google.com");
	    String title=driver.getTitle();
	    System.out.println(title);
	 /*   driver.findElement(By.linkText("Industries")).click();
	   Thread.sleep(3000);
	    String title1=driver.getCurrentUrl();
	   System.out.println(title1);
	   Thread.sleep(3000);*/
	    /*String title=driver.getTitle();
	   driver.findElement((By.id("gb_70")).click();*/
	    driver.findElement(By.name("q")).sendKeys("capgemini");
	    Thread.sleep(3000);
	    driver.findElement(By.name("gstyle")).click();
	    driver.findElement(By.id(""));
	    Select sel=new Select(driver.findElement(By.id("")));
	    sel.selectByIndex(1);
	    sel.selectByVisibleText("created on");
	    sel.selectByValue("http.......");
	}
}
